package com.entities;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product_sql")
public class Product {
	@Id
	int Dish_Number;
	int Quantity;
	double total;
	
	public int getDish_Number() {
		return Dish_Number;
	}
	public void setDish_Number(int dish_Number) {
		Dish_Number = dish_Number;
	}
	public String getDish() {
		return Dish;
	}
	public void setDish(String dish) {
		Dish = dish;
	}
	public byte[] getImage() {
		return Image;
	}
	public void setImage(byte[] image) {
		Image = image;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	String Dish;
	private byte[]  Image;
	
	
	

	public Product(int dish_Number, int quantity, double total, String dish, byte[] image) {
		super();
		Dish_Number = dish_Number;
		Quantity = quantity;
		this.total = total;
		Dish = dish;
		Image = image;
	}
	@Override
	public String toString() {
		return "Product [Dish_Number=" + Dish_Number + ", Quantity=" + Quantity + ", total=" + total + ", Dish=" + Dish
				+ ", Image=" + Arrays.toString(Image) + "]";
	}
	
	
	
	

}
